package Expl1;

public class Test {
	
	public static void main (String[] args) 
	{  
    Shape R= new Triangle ("Blue ", 2.5, 8.65);	
	system.out.println(" Area of Triangle is : " + T.area());
				
				
	Shape R= new Triangle ("Blue ", 1.5, 6.65);
	System.out.println(" Area of Rectangle is : " + R.area());
							
	
				
	Shape C= new Triangle ("Black ", 15.5,5.65);
	System.out.println(" Area of Cricle is : " + C.area());
							
			
				
	}
	
	

}
