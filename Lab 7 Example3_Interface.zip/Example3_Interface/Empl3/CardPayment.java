package Empl3;

public class CardPayment implements Payment
{
	public double Payment (double amount ) 
	{
		return amount;
	}
	
	
}
