package Empl3;

public class Test {

	public static void main(String[] args)
	{
	 Payment P1 = new CashPayment();
	 System.out.println(" Cash Payment is: " + P1.Payment(10000.00) + "Taka");
	 
	 
	 Payment P2 = new CardPayment();
	 System.out.println(" Cash Payment is: " + P2.Payment(10000.00) + "Taka");
	 
	 
	 
	 Payment P3 = new CashPayment();
	 System.out.println(" Cash Payment is: " + P3.Payment(10000.00) + "Taka");

	}

}
