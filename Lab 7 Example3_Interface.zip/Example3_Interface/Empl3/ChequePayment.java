package Empl3;

public class ChequePayment  implements Payment

	{
		public double Payment (double amount ) 
		{
			return amount;
		}
		
		
	}

