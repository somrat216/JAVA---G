package Empl3;

interface Payment 
{

	public double Payment (double amount );
	
	
}
