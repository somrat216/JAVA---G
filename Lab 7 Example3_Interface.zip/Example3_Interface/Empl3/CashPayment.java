package Empl3;

public class CashPayment implements Payment
{
	public double Payment (double amount ) 
	{ 
		return amount;
	
	}
}