public class Student extends Person

{
	public void Show ()
	{
		
		System.out.println( " A Student");
		
	}
}
