public class Test {

	public static void main(String[] args) 
	{
		Person P = new Person();
		Teacher T = new Teacher();
		Student S = new Student();
		
		P.Show(); 
		T.Show(); 
		S.Show(); 
		
		System.out.println ( " ********** Now Method OVER-RIDE Starts ****************** ");
		
		
		P = new Person (); 
		P.Show();
		
	    P = new Teacher();  
		T.Show ();
		
		P = new Student(); 
		S.Show();  
		
	}

}
