
public class Person 

{
	
	public void Show ()
	{
		
		System.out.println( " A Person");
		
	}

}
