public class Teacher extends Person
{
  
	
	public void  Show ()
	{
		
		System.out.println( " A Teacher ");
		
		
	} 
}
